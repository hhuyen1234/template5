﻿using WebApplication1.services.servicesimplement;
using WebApplication1.models.entities;
using WebApplication1.models.dto;
using Microsoft.AspNetCore.Mvc;
using System.IO;

namespace WebApplication1.services.serviceinterfaces
{
    public class StudentServices : IStudentServices
    {
        private static List<Student> s_students = new List<Student>();

        public StudentServices()
        {
        }

        public void AddStudent(AddStudentDto studentDto)
        {
            Student student = new Student
            {
                Id = s_students.Count + 1,
                Name = studentDto.Name,
                MSV = studentDto.MSV,
                BirthDay = studentDto.BirthDay,
            };
            s_students.Add(student);
        }

        /// <summary>
        ///  Lấy thông tin chi tiết sinh theo id (lấy id từ url path)
        /// </summary>
        public Student UpdateStudentInfo([FromBody] UpdateStudentDto updateStudentDto, int id)
        {
            var student = s_students.FirstOrDefault(x => x.Id == id);
            if (student != null)
            {
                student.Name = updateStudentDto.Name;
                student.MSV = updateStudentDto.MSV;
                student.BirthDay = updateStudentDto.BirthDay;
                return student;
            } else
            {
                return null;
            }
            
        }

        public Student GetStudentById(int id)
        {
            var Student = s_students.FirstOrDefault(e => e.Id == id);
            if (Student != null)
            {
                return Student;
            }
            return null;
        }

        public List<Student> GetAllStudents()
        {
            return s_students;
        }

        public Student DeleteStudentById(int id)
        {
            var student = s_students.FirstOrDefault(e => e.Id == id);
            if (student != null)
            {
                s_students.Remove(student);
                return student;
            }
            return null;
        }
    }
}
