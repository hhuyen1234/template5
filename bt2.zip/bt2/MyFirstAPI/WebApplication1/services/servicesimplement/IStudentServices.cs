﻿using WebApplication1.models.dto;
using WebApplication1.models.entities;

namespace WebApplication1.services.servicesimplement
{
    public interface IStudentServices
    {

        public void AddStudent(AddStudentDto studentDto);
        public Student UpdateStudentInfo(UpdateStudentDto updateStudentDto, int id);
        public Student GetStudentById(int id);
        public List<Student> GetAllStudents();
        public Student DeleteStudentById(int id);
    }
}
