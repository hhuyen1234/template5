﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.models.dto;
using WebApplication1.models.entities;
using WebApplication1.services.servicesimplement;

namespace WebApplication1.Controllers
{
    [Route("api/v1")]
    [ApiController]
    public class StudentController : Controller
    {
        private readonly IStudentServices _studentServices;

        public StudentController(IStudentServices studentServices)
        {
            _studentServices = studentServices;
        }

        [HttpPost("add-Student")]
        public IActionResult AddStudent([FromBody] AddStudentDto studentDto)
        {
            try
            {
                _studentServices.AddStudent(studentDto);
                return Ok(studentDto);
            } catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpPut("update-info/{id}")]
        public IActionResult UpdateStudentInfo([FromBody] UpdateStudentDto updateStudentDto, int id)
        {
            try
            {
                var NewStudent = _studentServices.UpdateStudentInfo(updateStudentDto, id);
                if (NewStudent != null)
                {
                    return Ok(NewStudent);
                }
                return BadRequest("Student does not exist");
            } catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        /// <summary>
        ///  Lấy sinh viên theo id (lấy id từ url param)
        /// </summary>
        [HttpGet("get-student/{id}")]
        public IActionResult GetStudentById(int id)
        {
            try
            {
                var students = _studentServices.GetStudentById(id);
                if (students != null)
                {
                    return Ok(students);
                }
                return BadRequest("Student does not exist");
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        /// <summary>
        ///  Lấy sinh viên theo id (lấy id từ url path)
        /// </summary>
        [HttpGet("get-student-by-id")]
        public IActionResult GetStudentById1(int id)
        {
            try
            {
                var students = _studentServices.GetStudentById(id);
                if (students != null)
                {
                    return Ok(students);
                }
                return BadRequest("Student does not exist");
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet("get-student")]
        public IActionResult GetAll()
        {
            try
            {
                var students = _studentServices.GetAllStudents();
                return Ok(students);
            } catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpDelete("delete/{id}")]
        public IActionResult DeleteStudentById(int id)
        {
            try
            {
               var student = _studentServices.DeleteStudentById(id);
               if (student != null)
                {
                    return Ok(student);
                }
                return BadRequest("Student does not exist");
                
            } catch (Exception ex) 
            { 
                return BadRequest(ex);
            }
        }
    }
}
