﻿namespace WebApplication1.models.dto
{
    public class UpdateStudentDto
    {
        public string Name { get; set; }
        public string MSV { get; set; }
        public DateTime BirthDay { get; set; }
    }
}
