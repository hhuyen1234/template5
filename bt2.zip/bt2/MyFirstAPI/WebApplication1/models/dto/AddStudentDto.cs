﻿namespace WebApplication1.models.entities
{
    public class AddStudentDto
    {
        public string Name { get; set; }
        public string MSV { get; set; }
        public DateTime  BirthDay { get; set; }
    }
}
